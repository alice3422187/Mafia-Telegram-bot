
import logging
import random
from aiogram import Bot, Dispatcher, executor, types

API_TOKEN = 'YOUR_BOT_TOKEN_HERE'

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

players = []
roles = ["Мафія", "Мирний", "Мирний", "Комісар"]

game_started = False

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.reply("Привіт! Це гра Мафія 🎭
Напиши /join щоб приєднатись до гри.")

@dp.message_handler(commands=['join'])
async def join_game(message: types.Message):
    global players, game_started
    if game_started:
        await message.reply("Гра вже почалась!")
        return
    user = message.from_user
    if user.id not in [p['id'] for p in players]:
        players.append({"id": user.id, "name": user.first_name})
        await message.answer(f"{user.first_name} приєднався до гри! ✅")
    else:
        await message.answer("Ти вже в грі!")

@dp.message_handler(commands=['players'])
async def list_players(message: types.Message):
    if not players:
        await message.reply("Ще ніхто не приєднався.")
        return
    text = "👥 Учасники гри:
" + "\n".join([f"- {p['name']}" for p in players])
    await message.reply(text)

@dp.message_handler(commands=['startgame'])
async def start_game(message: types.Message):
    global game_started
    if len(players) < 3:
        await message.reply("Потрібно мінімум 3 гравці!")
        return
    game_started = True
    assigned_roles = random.sample(roles, len(players))
    for i, player in enumerate(players):
        role = assigned_roles[i]
        await bot.send_message(player['id'], f"🎭 Твоя роль: {role}")
    await message.reply("Гра розпочалась! Ролі надіслано у приватні повідомлення.")

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
